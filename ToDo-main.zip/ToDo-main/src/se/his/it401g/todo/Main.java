package se.his.it401g.todo;

import javax.swing.JFrame;

public class Main {
    public static void main(String[] args) {
        new FrameCreator();
    }
}