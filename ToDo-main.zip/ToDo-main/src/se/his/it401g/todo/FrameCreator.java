package se.his.it401g.todo;

import javax.swing.*;
import javax.swing.JFrame;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class FrameCreator extends JFrame{
    public static ArrayList<Task> taskArray = new ArrayList<Task>();
    int totalTasks = 0;
    Task worktask;
    Task hometask;
    JLabel totalDisplay;
    JButton addWorkTask;
    JButton addHomeTask;
    JPanel taskPanel = new JPanel();
    JPanel buttonPanel = new JPanel();
    JPanel statusPanel = new JPanel();
    FrameCreator() {
        this.setTitle("ToDo - Planning Software");
        this.setBounds(100,100,600,700);
        //this.setResizable(false);
        taskPanel.setLayout(new GridLayout(10,1));
        buttonPanel.setLayout(new FlowLayout());

        addWorkTask = new JButton("Add Work Task");
        addHomeTask = new JButton("Add Home Task");

        totalDisplay = new JLabel();
        //Action listener for the addWorkTask JButton
        addWorkTask.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(e.getSource()==addWorkTask){
                    worktask = new WorkTask();
                    taskArray.add(worktask);
                    taskPanel.add(worktask.getGuiComponent());
                    draw();
                    totalTasks++;
                    totalDisplay.setText("[Placeholder] out of "+totalTasks+" tasks completed.");
                }
            }
        });
        //Action listener for the addHomeTask JButton
        addHomeTask.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(e.getSource()==addHomeTask){
                    hometask = new HomeTask();
                    taskArray.add(hometask);
                    taskPanel.add(hometask.getGuiComponent());
                    draw();
                    totalTasks++;
                    totalDisplay.setText("[Placeholder] out of "+totalTasks+" tasks completed.");
                }
            }
        });
        worktask = new WorkTask();
        hometask = new HomeTask();

        this.setLayout(new FlowLayout());
        this.add(buttonPanel);
        this.add(taskPanel);
        this.add(statusPanel,BorderLayout.SOUTH);
        buttonPanel.add(addWorkTask);
        buttonPanel.add(addHomeTask);
        statusPanel.add(totalDisplay);

        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    private void draw(){
        invalidate();
        validate();
        repaint();
    }
}